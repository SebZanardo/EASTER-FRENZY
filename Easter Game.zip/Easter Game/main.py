import pygame, sys, random, math
from pygame.locals import *
import engine
pygame.init()
 
# Colours
BACKGROUND = (255, 255, 255)


# Game Setup
FPS = 120
fpsClock = pygame.time.Clock()
monitor_width, monitor_height = pygame.display.Info().current_w, pygame.display.Info().current_h

monitor_aspect = monitor_width/monitor_height

#declaring ACTUAL game surface
surface_width, surface_height = 320*2, 180*2
surface_aspect = surface_width/surface_height

#upscale surface to fit monitor
if monitor_aspect>surface_aspect:
  window_width, window_height = (monitor_height/surface_height)*surface_width, monitor_height
else:
  window_width, window_height = monitor_width, (monitor_width/surface_width)*surface_height


SURF = pygame.Surface((surface_width, surface_height), pygame.SRCALPHA)

WINDOW = pygame.display.set_mode((window_width, window_height))

pygame.display.set_caption('Easter Game')






 


font=pygame.font.SysFont("Arial", 20)


# The main function that controls the game
def main () :
  looping = True


  world=engine.world(SURF, [20,40], 0.2, 40)

  scale_factor = surface_width/window_width

  angle=0
  
  dt=0
  count=0
  fullscreen=True
  while looping :
    # Get inputs
    for event in pygame.event.get():
      if event.type == QUIT :
        pygame.quit()
        sys.exit()

      if event.type == pygame.KEYDOWN and event.key == pygame.K_f:
        if fullscreen:
          fullscreen = False
          pygame.display.set_mode((surface_width, surface_height))
          scale_factor=1
        else:
          fullscreen = True
          pygame.display.set_mode((window_width, window_height))
          scale_factor = surface_width/window_width


    
    pressed=pygame.key.get_pressed()
    mouse_pos=pygame.mouse.get_pos()
    mouse_state=pygame.mouse.get_pressed()

    world.update(pressed, (mouse_pos[0]*scale_factor, mouse_pos[1]*scale_factor), mouse_state, dt)
    


 
    # Render elements of the game
    SURF.fill(BACKGROUND)



    world.render()


    

    if fullscreen:
      pygame.transform.scale(SURF, (window_width, window_height), WINDOW)
    else:
      WINDOW.blit(SURF, (0,0))

    WINDOW.blit(font.render(str(int(fpsClock.get_fps())), 0, (255,0,0)   ), (0,0) )

    
    #rot_image=pygame.transform.rotate(image, angle)
    #WINDOW.blit(rot_image, rot_image.get_rect(center=image.get_rect().center ))

    count+=1

    pygame.display.update()
    dt=fpsClock.tick(FPS)/1000
 
main()