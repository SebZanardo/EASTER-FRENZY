import pygame, random, math
from pygame.locals import *


class game_object:
    def __init__(self, surface_ref, camera_ref, pos):
        self.surface_ref=surface_ref
        self.camera_ref=camera_ref
        self.pos=pos


    def render(self):
        pass