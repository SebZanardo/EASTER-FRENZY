import pygame

from constants import SURFACE_WIDTH, SURFACE_HEIGHT, WINDOW_CAPTION
from spritesheet import SpriteSheet


pygame.init()

# Setup Pygame
monitor = pygame.display.Info()

MONITOR_WIDTH, MONITOR_HEIGHT = monitor.current_w, monitor.current_h

monitor_aspect = MONITOR_WIDTH/MONITOR_HEIGHT
surface_aspect = SURFACE_WIDTH/SURFACE_HEIGHT
#upscale surface to fit monitor
if monitor_aspect>surface_aspect:
  WINDOW_WIDTH, WINDOW_HEIGHT = (MONITOR_HEIGHT/SURFACE_HEIGHT)*SURFACE_WIDTH, MONITOR_HEIGHT
else:
  WINDOW_WIDTH, WINDOW_HEIGHT = MONITOR_WIDTH, (MONITOR_WIDTH/SURFACE_WIDTH)*SURFACE_HEIGHT

surface = pygame.Surface((SURFACE_WIDTH, SURFACE_HEIGHT), pygame.SRCALPHA)
window = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))

SCALE_FACTOR=SURFACE_WIDTH/WINDOW_WIDTH

pygame.display.set_caption(WINDOW_CAPTION)
clock = pygame.time.Clock()

# Load Fonts
FONT = pygame.font.Font("assets/nokiafc22.ttf", 20)

# Load Images, Spritesheets and Animations
BUNNY_SPRITESHEET = SpriteSheet("assets/player-Sheet.png", (64, 64), flip=True).slice_sheet()
BUNNY_ANIMATION = {"idle": [BUNNY_SPRITESHEET[i] for i in range(0,4)], "run":[BUNNY_SPRITESHEET[i] for i in range(4,8)], "dash":[BUNNY_SPRITESHEET[10], BUNNY_SPRITESHEET[10]]}
BUNNY_DASH_SPRITES = [BUNNY_SPRITESHEET[i] for i in range(11, 15)]

ENEMY_SPRITESHEET = SpriteSheet("assets/spider-Sheet.png", (64,64), flip=True).slice_sheet()
ENEMY_ANIMATION = {"run": [ENEMY_SPRITESHEET[i] for i in range(0,3)]}


EGG_SPRITESHEET = SpriteSheet("assets/egg-Sheet.png", (32, 32), (40,40)).slice_sheet()
BOOMERANG_SPRITESHEET = SpriteSheet("assets/boomerang-Sheet.png", (32, 32)).slice_sheet()

SHADOW_SPRITE = pygame.image.load("assets/shadow.png").convert_alpha()

# Load Audio
# TODO: Add audio