from gameobject import StatObj
import pygame


class Nest(StatObj):
    def __init__(self, pos, camera_ref, particle_ref):
        super().__init__(pos, camera_ref, particle_ref)
        
        self.sprite = [pygame.transform.scale(pygame.image.load(f"assets/nest_L{i}.png"), (128,64)).convert_alpha() for i in range(1,3)]
        
        
        self.sprite_size=self.sprite[0].get_size()
        self.image_offset=(self.sprite_size[0]//2, self.sprite_size[1]//2)


    def render(self, surface, layer):
        super().render(surface, self.sprite[layer])
        
        



